package com.kulchuri.crud.employee;

import com.kulchuri.crud.db.CrudDb;
import java.io.InputStream;
import java.sql.*;

public class EmployeeDao {

    private Connection conn = null;
    private PreparedStatement ps = null;
    private ResultSet rs = null;

    public EmployeeDao() {
    }

    public boolean addEmployee(EmployeeDto dto, InputStream photo) {
        boolean flag = false;
        if (conn == null) {
            conn = CrudDb.getCrudDb();
        }

        try {
            String query = "insert into employee(name, email, pwd, dob, dor, hobby, gender, city, photo) values(?,?,?,?,?,?,?,?,?)";
            ps = conn.prepareStatement(query);
            ps.setString(1, dto.getName());
            ps.setString(2, dto.getEmail());
            ps.setString(3, dto.getPwd());
            ps.setString(4, dto.getDob());
            ps.setString(5, dto.getDor());
            ps.setString(6, dto.getHobby());
            ps.setString(7, dto.getGender());
            ps.setString(8, dto.getCity());
            ps.setBlob(9, photo);

            if (ps.executeUpdate() > 0) {
                flag = true;
            }

        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("exception at employee method: " + e);
        } finally {
            ps = null;
            conn = null;
            return flag;
        }
    }
}
