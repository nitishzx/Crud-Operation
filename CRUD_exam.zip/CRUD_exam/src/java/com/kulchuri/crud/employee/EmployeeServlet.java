/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.kulchuri.crud.employee;

import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;
@WebServlet(urlPatterns = {"/register"})
//multipart value aaraha hai photo se to ushko config kiya hai
@MultipartConfig(maxFileSize = 989899999)
/**
 *
 * @author hp
 */
public class EmployeeServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
       // super.doPost(req, resp); //To change body of generated methods, choose Tools | Templates.
       
       String name=req.getParameter("name");
       String email=req.getParameter("email");
       String pwd=req.getParameter("pwd");
       String gender=req.getParameter("gender");
       String dob=req.getParameter("dob");
       String city=req.getParameter("city");
       
       //read karna hai hobby jo checkbox hai to ishkeliye internally array banega
       
       String arr[]= req.getParameterValues("hobby");
       
       String hobby="";
       for(String s: arr){
       hobby = hobby+s;
       }
       
       //image get karne ke liye part naam ka method use kiya hai (multi part likha tha html me)
       //part class hai aur dushra object hai
       
        Part part=req.getPart("photo");
        InputStream photo=part.getInputStream();
        
        //data rquest ko database me store karege ushke liye method banayi hai Employeedto me ush class ka object banakar
        
        EmployeeDto dto=new EmployeeDto();
        //set the requestparameter data to dto object
        
        dto.setName(name);
        dto.setEmail(email);
        dto.setGender(gender);
        dto.setHobby(hobby);
        dto.setDob(dob);
        dto.setDor("12/12/2019");
        dto.setCity(city);
        dto.setPwd(pwd);
        
        //create the object of EmployeeDao class banaya kyo ki add naam ka method define hai
        
        EmployeeDao dao= new EmployeeDao();
        //to call addEmployee() method to store data into database table aur photo yaha se direct method me daal rahe hai
        boolean f=dao.addEmployee(dto,photo);
        PrintWriter ps=resp.getWriter();
        
        if(f){
        ps.println("sucess");}
        else{
        ps.print("failed");}
        
        
        
    }
    
}
